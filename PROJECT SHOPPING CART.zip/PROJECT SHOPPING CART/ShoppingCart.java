package MyShoppingCart;
import java.util.ArrayList;


public class ShoppingCart {
    private ArrayList<CartItem> cartItems;

    public ShoppingCart() {
        cartItems = new ArrayList<>();
    }

    public void addProduct(Product product, int quantity) {
        for (CartItem item : cartItems) {
            if (item.getProduct().getName().equals(product.getName())) {
                item.setQuantity(item.getQuantity() + quantity);
                return;
            }
        }
        cartItems.add(new CartItem(product, quantity));
    }

    public void removeProduct(Product product) {
        cartItems.removeIf(item -> item.getProduct().getName().equals(product.getName()));
    }

    public ArrayList<CartItem> getCartItems() {
        return cartItems;
    }

    public double calculateTotal() {
        return cartItems.stream().mapToDouble(CartItem::getTotalPrice).sum();
              }
      }
