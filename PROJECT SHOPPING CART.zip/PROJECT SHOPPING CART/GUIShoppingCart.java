package MyShoppingCart;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

import static java.awt.Color.darkGray;

public class GUIShoppingCart extends JFrame {
    private ArrayList<Product> products = new ArrayList<>();
    private ShoppingCart shoppingCart;
    private JComboBox<String> productComboBox;
    private JTextField quantityField;
    private DefaultTableModel cartModel;
    private JLabel totalLabel;

    public GUIShoppingCart() {
        shoppingCart = new ShoppingCart();
        setTitle("                                             WELCOME TO  POOKIE CAFE  ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 500);
        setLayout(new BorderLayout());


        // Populate products
        products.add(new Product("HOT COFFEE", 15, 5));
        products.add(new Product("COLD COFFEE", 20, 5.5));
        products.add(new Product("LATTE", 20, 6));
        products.add(new Product("AMERICANO", 20, 6.50));
        products.add(new Product("CAPPUCCINO", 20, 7.00));
        products.add(new Product("DOUBLE ESPRESSO", 20, 7.50));
        products.add(new Product("MOCHA", 20, 8.00));
        products.add(new Product("CHOCOLATE PASTRY", 20, 13));
        products.add(new Product("VANILLA PASTRY", 20, 10));
        products.add(new Product("RED VELVET PASTRY", 20, 15));
        products.add(new Product("TIRAMISU", 20, 20));
        products.add(new Product("CROISSANT", 20, 20));

        // Product Selection Panel
        JPanel productPanel = new JPanel(new FlowLayout());
        productPanel.setBackground(Color.pink);
        productComboBox = new JComboBox<>();
        for (Product product : products) {
            productComboBox.addItem(product.getName());
        }
        quantityField = new JTextField(5);
        JButton addButton = new JButton("Add to Cart");
        JButton stockRequestButton = new JButton("Stock Request");
        productPanel.add(new JLabel("Product:"));
        productPanel.add(productComboBox);
        productPanel.add(new JLabel("Quantity:"));
        productPanel.add(quantityField);
        productPanel.add(addButton);
        productPanel.add(stockRequestButton);
        add(productPanel, BorderLayout.NORTH);

        // Cart Display Panel
        String[] columns = {"Product Name", "Quantity", "Price"};
        cartModel = new DefaultTableModel(columns, 0);
        JTable cartTable = new JTable(cartModel);
        JScrollPane cartScrollPane = new JScrollPane(cartTable);
        add(cartScrollPane, BorderLayout.CENTER);

        // Summary Panel
        JPanel summaryPanel = new JPanel(new FlowLayout());
        totalLabel = new JLabel("Total: ₹0.00");
        JButton removeButton = new JButton("Remove Item");
        JButton confirmOrderButton = new JButton("Confirm Order");
        summaryPanel.add(totalLabel);
        summaryPanel.add(removeButton);

        summaryPanel.add(confirmOrderButton);
        add(summaryPanel, BorderLayout.SOUTH);

        //Add Product to Cart
        addButton.addActionListener(e -> {
            try {
                String productName = (String) productComboBox.getSelectedItem();
                int quantity = Integer.parseInt(quantityField.getText());
                if (quantity <= 0) throw new NumberFormatException();

                Product selectedProduct = products.stream()
                        .filter(p -> p.getName().equals(productName))
                        .findFirst()
                        .orElse(null);

                if (selectedProduct == null) return;

                if (quantity > selectedProduct.getStock()) {
                    JOptionPane.showMessageDialog(this, "SORRY SIR! THIS ITEMS AREN'T ENOUGH IN STOCK. IT WILL TAKE SOME TIME.\nYOU CAN MAKE A STOCK REQUEST! AND ORDER AGAIN AFTER A WHILE ", "Stock Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    shoppingCart.addProduct(selectedProduct, quantity);
                    selectedProduct.setStock(selectedProduct.getStock() - quantity);
                    cartModel.addRow(new Object[]{productName, quantity, selectedProduct.getPrice() * quantity});
                    updateTotal();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid quantity!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Stock Request
        stockRequestButton.addActionListener(e -> {
            String productName = (String) productComboBox.getSelectedItem();
            JOptionPane.showMessageDialog(this, "STOCK IN REQUEST SEND FOR " + productName);
        });

        // Remove Item from Cart
        removeButton.addActionListener(e -> {
            int selectedRow = cartTable.getSelectedRow();
            if (selectedRow >= 0) {
                String productName = (String) cartModel.getValueAt(selectedRow, 0);
                int quantity = (int) cartModel.getValueAt(selectedRow, 1);
                Product product = products.stream()
                        .filter(p -> p.getName().equals(productName))
                        .findFirst()
                        .orElse(null);
                if (product != null) {
                    product.setStock(product.getStock() + quantity);
                }
                shoppingCart.removeProduct(product);
                cartModel.removeRow(selectedRow);
                updateTotal();
            } else {
                JOptionPane.showMessageDialog(this, "Select an item to remove!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Confirm Order
        confirmOrderButton.addActionListener(e -> {
 JOptionPane.showMessageDialog(this, "Thanks for ordering.Your total bill is"+totalLabel.getText());
            shoppingCart.getCartItems().clear();
            cartModel.setRowCount(0);
            updateTotal();
        });
    }

    private void updateTotal() {
        double total = shoppingCart.calculateTotal();
        totalLabel.setText("Total: ₹" + total);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GUIShoppingCart app = new GUIShoppingCart();
            app.setVisible(true);
             });
       }

}